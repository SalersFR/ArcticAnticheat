package polar.ac.event.client;

import com.comphenix.packetwrapper.WrapperPlayClientArmAnimation;
import polar.ac.data.PlayerData;
import polar.ac.event.Event;

public class ArmAnimationEvent extends Event {

    public ArmAnimationEvent(PlayerData data, WrapperPlayClientArmAnimation wrapper) {

    }
}
