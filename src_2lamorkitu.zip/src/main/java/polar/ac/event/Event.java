package polar.ac.event;

public abstract class Event {

}
