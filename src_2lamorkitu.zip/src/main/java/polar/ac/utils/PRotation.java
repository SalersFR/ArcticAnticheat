package polar.ac.utils;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public class PRotation {

    private final float yaw, pitch;
}
